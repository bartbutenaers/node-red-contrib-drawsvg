/*
    Copyright 2020 Joseph LIARD. All Rights Reserved.
    
    This file is part of www.drawsvg.org
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

/**
 * @fileoverview  Drawsvg custom application UI sample .
 * @author liard.joseph@gmail.com
 */
 
// The SVG Engine application, implements ISVGEngineApp
var drwApp = {};
	
// SVG view implements ISVGView (required)
drwApp.svgView = {	
	// the svg window div element
	getSVGWindowContainer : function() {
		return document.getElementById("svgwindow");
	},
	// The maximun sgv size
	getSVGMaxPixelSize : function() {
		console.log("drwApp.svgView.getSVGMaxPixelSize ");
		let w = document.getElementById("svgwindow");
		console.log("drwApp.svgView.getSVGMaxPixelSize "+w.clientWidth);
		return {width:w.clientWidth ,height:460};
	},	
	// Setting the svg area size
	setSVGPixelSize : function(sz) {			
	},
	// Indicates whether the visualization container has scrollbars to represent an SVG document larger than the element.
	hasScrollbars : function() {
		return false;
	}
};
drwApp.getSVGView = function() {return drwApp.svgView;};
	
// Notify SVG engine ready
drwApp.onSVGEngineLoad = function(engine) {
	console.log("drwApp.onSVGEngineLoad engine="+engine);
	drwApp.engine=engine;
};
// Show started task message
drwApp.showTaskMessage = function(msg) {
	console.log("drwApp.showTaskMessage "+msg);
	document.getElementById("taskMessage").innerText = msg;
};
// Erase task message
drwApp.eraseTaskMessage = function() {
	//document.getElementById("taskMessage").innerText ="";
};
// Base view implements IView
drwApp.baseView = {
	// Set task started state. Change button task style
	setTaskState : function(taskId,started) {
		console.log("drwApp.baseView.setTaskState "+taskId+" "+started);
		let btn = document.getElementById(taskId+"Btn");
		if (btn!=null) {
			if (started==true) btn.style.border="1px dashed black";
			else btn.style.removeProperty("border");
		}
	},
	// Set task enabled state. 
	setTaskEnabled : function(taskId,enabled) {
		console.log("drwApp.baseView.setTaskEnabled "+taskId+" "+enabled);
		let btn = document.getElementById(taskId+"Btn");
		if (btn!=null) {
			if (enabled==true) btn.disabled=false;
			else btn.disabled=true;
		}
	},
	// Disable a task list (white space separator).
	disableTasks : function(taskList) {
		console.log("drwApp.baseView.disableTasks "+taskList);
		let list = taskList.split(" ");
		for (let i in list) this.setTaskEnabled(list[i],false);
	},
	// Return to start state
	reset : function() {
		console.log("drwApp.baseView.reset");
	},
	// clear input values
	clearInputValues : function(ids) {
		for (let i in ids) {
			let w = document.getElementById(ids[i]);
			console.log("drwApp.baseView.clearInputValues "+ids[i]+" "+w+" "+w.value);
			w.value="";
		}
	},
	// clear labels
	clearLabels : function(ids) {
		for (let i in ids) {
			let w = document.getElementById(ids[i]);
			console.log("drwApp.baseView.clearLabels "+ids[i]+" "+w);
			w.innerHTML="";
		}
	},
	// set disabled attribute
	setDisabled : function(ids,v) {
		for (let i in ids) {
			let w = document.getElementById(ids[i]);
			console.log("drwApp.baseView.setDisabled "+ids[i]+" "+w+" "+w.disabled);
			w.disabled=v;
		}
	},
	// set input value
	setValue: function(id,v) {
		console.log("drwApp.baseView.setValue "+id+" "+v);
		let w = document.getElementById(id);
		w.value=v;
	},
	setChecked: function(id,v) {
		console.log("drwApp.baseView.setChecked "+id+" "+v);
		let w = document.getElementById(id);
		w.checked=v;
	},
	// set label text
	setLabel: function(id,v) {
		console.log("drwApp.baseView.setValue "+id+" "+v);
		let w = document.getElementById(id);
		w.innerHTML=v;
	}
}



// Nav view implements INavView
drwApp.navView = {
	__proto__: drwApp.baseView
};
drwApp.getNavView = function() {return drwApp.navView;};


//Document view implements IDocumentView
drwApp.documentView = {
	__proto__: drwApp.baseView
};
drwApp.getDocumentView = function() {return drwApp.documentView;};

//Edit view implements IEditView
drwApp.editView = {
	__proto__: drwApp.baseView,
	onAddUndo : function() {
		console.log("editView.onAddUndo "+drwApp.engine.getDocumentPresenter().TASK);
		// update undo/redo  title and count
		let u=document.getElementById("undoBtn"), r=document.getElementById("redoBtn");
		let p=drwApp.engine.getEditPresenter();
		let n=p.getRedoCount();		
		u.innerHTML=p.getUndoTitle()+" ("+p.getUndoCount()+")";
		u.disabled=false;
		r.innerHTML= n==0 ? "Redo" : (p.getRedoTitle()+" ("+n+")");
		r.disabled=n==0;
	},
	onAddRedo : function() {
		console.log("editView.onAddRedo");
		// update redo/redo title and count
		let u=document.getElementById("undoBtn"), r=document.getElementById("redoBtn");
		let p=drwApp.engine.getEditPresenter();
		let n=p.getUndoCount();
		r.innerHTML=p.getRedoTitle()+" ("+p.getRedoCount()+")";
		r.disabled=false;
		u.innerHTML=n==0 ? "Undo" : (p.getUndoTitle()+" ("+n+")");
		u.disabled=n==0;
	},
	onClearUndoList : function() {
		// update redo/redo title and count
		let u=document.getElementById("undoBtn"), r=document.getElementById("redoBtn");
		u.innerHTML="Undo";
		r.innerHTML="Redo";
		u.disabled=true;
		r.disabled=true;		
	}
};
drwApp.getEditView = function() {return drwApp.editView;};

//Layer view  implements ILayerView
drwApp.layerView = {
	__proto__: drwApp.baseView,
	setLayerList : function(layers,inputLayerId) {
		console.log("drwApp.layerView.setLayerList "+layers.join(",")+" "+inputLayerId);
	}
};
drwApp.getLayerView = function() {return drwApp.layerView;};

//ElementsDrawingTaskView view implements IElementsDrawingTaskView
drwApp.elementsDrawingTaskView = {
	__proto__: drwApp.baseView
};
drwApp.getElementsDrawingTaskView = function() {return drwApp.elementsDrawingTaskView;};

//Shape drawing  view implements IShapeDrawingView
drwApp.shapeDrawingView = {
	__proto__: drwApp.baseView,
	reset : function() {
		console.log("drwApp.shapeDrawingView.reset");
	},
	onShapeTaskFinished : function() {
		console.log("drwApp.shapeDrawingView.onShapeTaskFinished");
	}
};
drwApp.getShapeDrawingView = function() {return drwApp.shapeDrawingView;};

//Draw controls view  implements IDrawControlsView
drwApp.drawControlsView = {
	__proto__: drwApp.baseView,
	reset : function() {
		console.log("drwApp.drawControlsView.reset");
	}
};
drwApp.getDrawControlsView = function() {return drwApp.drawControlsView;};

//SelectionView view implements ISelectionView
drwApp.selectionView = {
	__proto__: drwApp.baseView,
	drawnList: [],
	selDrawnList: [],
	addDrawn : function(id) {
		console.log("drwApp.selectionView.addDrawn "+id);
		this.drawnList.push(id);
		console.log("drwApp.selectionView.addDrawn "+this.drawnList.join(","));
	},
	removeDrawn : function(id) {
		console.log("drwApp.selectionView.removeDrawn "+id);
		let index = this.drawnList.indexOf(id);
		if (index != -1) {this.drawnList.splice(index, 1);}
		console.log("drwApp.selectionView.removeDrawn "+this.drawnList.join(","));
	},
	changeDrawn : function(aId,bId) {
		console.log("drwApp.selectionView.changeDrawn "+aId+" into "+bId);
		let index = this.drawnList.indexOf(aId);
		if (index != -1) {this.drawnList[index]=bId;}
		console.log("drwApp.selectionView.changeDrawn "+this.drawnList.join(","));
	},
	selectDrawn : function(ids) {
		console.log("drwApp.selectionView.selectDrawn "+ids.join(","));
		this.selDrawnList = ids;
		console.log("drwApp.selectionView.selectDrawn "+this.selDrawnList.join(","));
	},
	clearDrawn : function() {
		console.log("drwApp.selectionView.clearDrawn");
		this.drawnList=[];
	},
	reset : function() {
		console.log("drwApp.selectionView.reset");
		this.drawnList=[];
		this.selDrawnList=[];
	}
	
};
drwApp.getSelectionView = function() {return drwApp.selectionView;};

//Element style view  view implements IElementStyleView
drwApp.elementStyleView = {
	__proto__: drwApp.baseView,
	onRemoved : function() {
		console.log("drwApp.elementStyleView.onRemoved");
	},
	resetView : function() {
		console.log("drwApp.elementStyleView.resetView");
	}
}
//Stroke view implements IStrokeView
drwApp.strokeView = {
	__proto__: drwApp.elementStyleView,
	// input id list
	inputIds : ["stroke-color","stroke-width","stroke-opacity","stroke-dash-array","line-cap-butt","line-cap-round","line-cap-square",
	"line-join-miter","line-join-round","line-join-bevel","stroke-miter-limit","stroke-dash-offset"],
	// button id list
	btnIds : ["stroke-color-btn","stroke-none-btn","stroke-width-remove-btn","stroke-opacity-remove-btn","stroke-grd-choose-btn","stroke-grd-remove-btn",
	"stroke-pattern-choose-btn","stroke-pattern-remove-btn","stroke-dash-array-remove-btn","line-cap-remove-btn","line-join-remove-btn","stroke-miter-limit-remove-btn",
	"stroke-dash-offset-remove-btn"],
	// label id list
	labelIds:["stroke-gradient","stroke-pattern"],
	// clean all stroke field values
	clearStrokeFields : function() {
		console.log("drwApp.strokeView.clearStrokeFields ");
		this.clearInputValues(this.inputIds);
		this.clearLabels(this.labelIds);
	},
	setStrokeTextFieldsEnabled : function(bStrokeElement,bStrokeText) {
		console.log("drwApp.strokeView.setStrokeTextFieldsEnabled "+bStrokeElement+" "+bStrokeText);
		this.setDisabled(this.inputIds.concat(this.btnIds),bStrokeElement==true ? false : true);
	},
	setStrokeGradient : function(v) {
		console.log("drwApp.strokeView.setStrokeGradient "+v);
		this.setLabel("stroke-gradient",v.getAttribute("id"));
		this.setValue("stroke-color","");
		this.setLabel("stroke-pattern","");
	},
	setStrokePattern : function(v) {
		console.log("drwApp.strokeView.setStrokePattern "+v);
		this.setLabel("stroke-pattern",v.getAttribute("id"));
		this.setValue("stroke-color","");
		this.setLabel("stroke-gradient","");		
	},
	setStrokeColor : function(v) {
		console.log("drwApp.strokeView.setStrokeColor "+v);
		this.setValue("stroke-color",v);
		document.getElementById("stroke-color-btn").style.setProperty("background-color",v);
		this.setLabel("stroke-gradient","");
		this.setLabel("stroke-pattern","");
	},
	setStrokeWidth : function(v) {
		console.log("drwApp.strokeView.setStrokeWidth "+v);
		this.setValue("stroke-width",v);
	},
	setStrokeLinecap : function(v) {
		console.log("drwApp.strokeView.setStrokeLinecap "+v);
		this.setChecked("line-cap-"+v,true);
	},
	setStrokeLinejoin : function(v) {
		console.log("drwApp.strokeView.setStrokeLinejoin "+v);
		this.setChecked("line-join-"+v,true);
	},
	setStrokeOpacity : function(v) {
		console.log("drwApp.strokeView.setStrokeOpacity "+v);
		this.setValue("stroke-opacity",v);
	},
	setStrokeMiterlimit : function(v) {
		console.log("drwApp.strokeView.setStrokeMiterlimit "+v);
		this.setValue("stroke-miter-limit",v);
	},
	setStrokeDashOffset : function(v) {
		console.log("drwApp.strokeView.setStrokeDashOffset "+v);
		this.setValue("stroke-dash-offset",v);
	},
	setStrokeDashArray : function(v) {
		console.log("drwApp.strokeView.setStrokeDashArray "+v);
		this.setValue("stroke-dash-array",v);
	},
	setStrokeVectorEffect : function(v) {
		console.log("drwApp.strokeView.setStrokeVectorEffect "+v);
	},
	setSvg12Enabled : function(v) {
		console.log("drwApp.strokeView.setSvg12Enabled "+v);
	},
	removeStroke : function() {
		console.log("drwApp.strokeView.removeStroke");
		this.setValue("stroke-color","");
		this.setLabel("stroke-gradient","");
		this.setLabel("stroke-pattern","");
	},
	removeStrokeWidth : function() {
		console.log("drwApp.strokeView.removeStrokeWidth");
		this.setValue("stroke-width","");
	},
	removeStrokeLinecap : function() {
		console.log("drwApp.strokeView.removeStrokeLinecap");
		this.setChecked("line-cap-butt",false);
		this.setChecked("line-cap-round",false);
		this.setChecked("line-cap-square",false);
	},
	removeStrokeLinejoin : function() {
		console.log("drwApp.strokeView.removeStrokeLinejoin");
		this.setChecked("line-join-miter",false);
		this.setChecked("line-join-round",false);
		this.setChecked("line-join-bevel",false);
	},
	removeStrokeOpacity : function() {
		console.log("drwApp.strokeView.removeStrokeOpacity");
		this.setValue("stroke-opacity","");
	},
	removeStrokeMiterlimit : function() {
		console.log("drwApp.strokeView.removeStrokeMiterlimit");
		this.setValue("stroke-miter-limit","");
	},
	removeStrokeDashOffset : function() {
		console.log("drwApp.strokeView.removeStrokeDashOffset");
		this.setValue("stroke-dash-offset","");
	},
	removeStrokeDashArray : function() {
		console.log("drwApp.strokeView.removeStrokeDashArray");
		this.setValue("stroke-dash-array","");
	},
	removeStrokeVectorEffect : function() {
		console.log("drwApp.strokeView.removeStrokeVectorEffect");
	},
	onCreateGradient : function(v) {
		console.log("drwApp.strokeView.onCreateGradient "+v);
	},
	onModifyGradient : function(v) {
		console.log("drwApp.strokeView.onModifyGradient "+v);
	},
	onDeleteGradient : function(id) {
		console.log("drwApp.strokeView.onDeleteGradient "+id);
	},
	onSelectGradient : function(v) {
		console.log("drwApp.strokeView.onSelectGradient "+v);
	},
	onCreatePattern : function(v) {
		console.log("drwApp.strokeView.onCreatePattern "+v);
	},
	onModifyPattern : function(v) {
		console.log("drwApp.strokeView.onModifyPattern "+v);
	},
	onDeletePattern : function(id) {
		console.log("drwApp.strokeView.onDeletePattern "+id);
	},
	onSelectPattern : function(v) {
		console.log("drwApp.strokeView.onSelectPattern "+v);
	},
	reset : function() {
		console.log("drwApp.strokeView.reset");
	}
	
};
drwApp.getStrokeView = function() {return drwApp.strokeView;};

//Fill view implements IFillView
drwApp.fillView = {
	__proto__: drwApp.elementStyleView,
	// input id list
	inputIds : ["fill-color","fill-opacity"],
	// button id list
	btnIds : ["fill-color-btn","fill-none-btn","fill-opacity-remove-btn","fill-grd-choose-btn","fill-grd-remove-btn","fill-pattern-choose-btn","fill-pattern-remove-btn",
	"filter-tool-btn","filter-remove-btn"],
	labelIds:["fill-gradient","fill-pattern","filter"],
	clearFillFields : function() {
		console.log("drwApp.fillView.clearFillFields ");
		this.clearInputValues(this.inputIds);
		this.clearLabels(this.labelIds);
	},
	setFillTextFieldsEnabled : function(bfillElement,bFillText) {
		console.log("drwApp.fillView.setFillTextFieldsEnabled "+bfillElement+" "+bFillText);
		this.setDisabled(this.inputIds.concat(this.btnIds),bfillElement==true ? false : true);
	},
	setFillColor : function(v) {
		console.log("drwApp.fillView.setFillColor "+v);
		this.setValue("fill-color",v);
		document.getElementById("fill-color-btn").style.setProperty("background-color",v);
		this.setLabel("fill-gradient","");
		this.setLabel("fill-pattern","");
	},
	setFillOpacity : function(v) {
		console.log("drwApp.fillView.setFillOpacity "+v);
		this.setValue("fill-opacity",v);
	},
	setFillGradient : function(v) {
		console.log("drwApp.fillView.setFillGradient "+v);
		this.setLabel("fill-gradient",v.getAttribute("id"));
		this.setValue("fill-color","");
		this.setLabel("fill-pattern","");
	},
	setFillRule : function(v) {
		console.log("drwApp.fillView.setFillRule "+v);
	},
	setFillPattern : function(v) {
		console.log("drwApp.fillView.setFillPattern "+v);
		this.setLabel("fill-pattern",v.getAttribute("id"));
		this.setValue("fill-color","");
		this.setLabel("fill-gradient","");
	},
	setFilter : function(v) {
		console.log("drwApp.fillView.setFilter "+v);
		this.setLabel("filter",v.getAttribute("id"));
	},
	removeFill : function() {
		console.log("drwApp.fillView.removeFill");
		this.setValue("fill-color","");
		this.setLabel("fill-gradient","");
		this.setLabel("fill-pattern","");
	},
	removeFillOpacity : function() {
		console.log("drwApp.fillView.removeFillOpacity");
		this.setValue("fill-opacity","");
	},
	removeFillRule : function() {
		console.log("drwApp.fillView.removeFillRule");
	},
	removeFilter : function() {
		console.log("drwApp.fillView.removeFilter");
		this.setLabel("filter","");
	},
	onCreateGradient : function(v) {
		console.log("drwApp.fillView.onCreateGradient "+v);
	},
	onModifyGradient : function(v) {
		console.log("drwApp.fillView.onModifyGradient "+v);
	},
	onDeleteGradient : function(id) {
		console.log("drwApp.fillView.onDeleteGradient "+id);
	},
	onSelectGradient : function(v) {
		console.log("drwApp.fillView.onSelectGradient "+v);
	},
	onCreatePattern : function(v) {
		console.log("drwApp.fillView.onCreatePattern "+v);
	},
	onModifyPattern : function(v) {
		console.log("drwApp.fillView.onModifyPattern "+v);
	},
	onDeletePattern : function(id) {
		console.log("drwApp.fillView.onDeletePattern "+id);
	},
	onSelectPattern : function(v) {
		console.log("drwApp.fillView.onSelectPattern "+v);
	},	
	onCreateFilter : function(v) {
		console.log("drwApp.fillView.onCreateFilter "+v);
	},
	onModifyFilter : function(v) {
		console.log("drwApp.fillView.onModifyFilter "+v);
	},
	onDeleteFilter : function(id) {
		console.log("drwApp.fillView.onDeleteFilter "+id);
	},
	onSelectFilter : function(v) {
		console.log("drwApp.fillView.onSelectFilter "+v);
	}
}
drwApp.getFillView = function() {return drwApp.fillView;};

//Text style view implements ITextStyleView
drwApp.textStyleView = {
	__proto__: drwApp.elementStyleView,
	// input id list
	inputIds : ["font-family","font-size","font-style-normal","font-style-italic","font-style-oblique","font-weight-normal","font-weight-bold",
	"text-anchor-start","text-anchor-middle","text-anchor-end","text-decoration-underline","text-decoration-overline","text-decoration-line-through"],
	// button id list
	btnIds : ["font-family-btn","font-family-remove-btn","font-size-remove-btn","font-style-remove-btn","font-weight-remove-btn","text-anchor-remove-btn",
	"text-decoration-remove-btn"],
	labelIds:[],
	clearFontFields : function() {
		console.log("drwApp.textStyleView.clearFontFields");
		this.clearInputValues(this.inputIds);
		this.clearLabels(this.labelIds);
	},
	setFontFieldsEnabled : function(v) {
		console.log("drwApp.textStyleView.setFontFieldsEnabled "+v);
		this.setDisabled(this.inputIds.concat(this.btnIds),v==true ? false : true);
	},
	setFontFamily : function(v) {
		console.log("drwApp.textStyleView.setFontFamily "+v);
		this.setValue("font-family",v);
	},
	setFontWeight : function(v) {
		console.log("drwApp.textStyleView.setFontWeight "+v);
		this.setChecked("font-weight-"+v,true);
	},
	setFontStyle : function(v) {
		console.log("drwApp.textStyleView.setFontStyle "+v);
		this.setChecked("font-style-"+v,true);
	},
	setFontStretch : function(v) {
		console.log("drwApp.textStyleView.setFontStretch "+v);
	},
	setFontVariant : function(v) {
		console.log("drwApp.textStyleView.setFontVariant "+v);
	},
	setFontSize : function(v) {
		console.log("drwApp.textStyleView.setFontSize "+v);
		this.setValue("font-size",v);
	},
	setTextAnchor : function(v) {
		console.log("drwApp.textStyleView.setTextAnchor "+v);
		this.setChecked("text-anchor-"+v,true);
	},
	setTextDecoration : function(v) {
		console.log("drwApp.textStyleView.setTextDecoration "+v);
		this.setChecked("text-decoration-"+v,true);
	},
	removeFontFamily : function() {
		console.log("drwApp.textStyleView.removeFontFamily");
		this.setValue("font-family","");
	},
	removeFontWeight : function() {
		console.log("drwApp.textStyleView.removeFontWeight");
		this.setChecked("font-weight-normal",true);
	},
	removeFontVariant : function() {
		console.log("drwApp.textStyleView.removeFontVariant");
	},
	removeFontStyle : function() {
		console.log("drwApp.textStyleView.removeFontStyle");
		this.setChecked("font-style-normal",true);
	},
	removeFontStretch : function() {
		console.log("drwApp.textStyleView.removeFontStretch");
	},
	removeFontSize : function() {
		console.log("drwApp.textStyleView.removeFontSize");
		this.setValue("font-size","");
	},
	removeTextAnchor : function() {
		console.log("drwApp.textStyleView.removeTextAnchor");
		this.setChecked("text-anchor-start",true);
	},
	removeTextDecoration : function() {
		console.log("drwApp.textStyleView.removeTextDecoration");
		this.setChecked("text-decoration-underline",false);
		this.setChecked("text-decoration-overline",false);
		this.setChecked("text-decoration-line-through",false);
	},
	resetView : function() {
		console.log("drwApp.textStyleView.resetView");
	},
	setFillPattern : function(v) {
		console.log("drwApp.textStyleView.setFillPattern "+v);
	},
	setFillGradient : function(v) {
		console.log("drwApp.textStyleView.setFillGradient "+v);
	},
	setFilter : function(v) {
		console.log("drwApp.textStyleView.setFilter "+v);
	},
	onCreateGradient : function(v) {
		console.log("drwApp.textStyleView.onCreateGradient "+v);
	},
	onModifyGradient : function(v) {
		console.log("drwApp.textStyleView.onModifyGradient "+v);
	},
	onDeleteGradient : function(id) {
		console.log("drwApp.textStyleView.onDeleteGradient "+id);
	},
	onSelectGradient : function(v) {
		console.log("drwApp.textStyleView.onSelectGradient "+v);
	},
	onCreatePattern : function(v) {
		console.log("drwApp.textStyleView.onCreatePattern "+v);
	},
	onModifyPattern : function(v) {
		console.log("drwApp.textStyleView.onModifyPattern "+v);
	},
	onDeletePattern : function(id) {
		console.log("drwApp.textStyleView.onDeletePattern "+id);
	},
	onSelectPattern : function(v) {
		console.log("drwApp.textStyleView.onSelectPattern "+v);
	},	
	onCreateFilter : function(v) {
		console.log("drwApp.textStyleView.onCreateFilter "+v);
	},
	onModifyFilter : function(v) {
		console.log("drwApp.textStyleView.onModifyFilter "+v);
	},
	onDeleteFilter : function(id) {
		console.log("drwApp.textStyleView.onDeleteFilter "+id);
	},
	onSelectFilter : function(v) {
		console.log("drwApp.textStyleView.onSelectFilter "+v);
	}
}
drwApp.getTextStyleView = function() {return drwApp.textStyleView;};

//Marker view implements IMarkerStyleView
drwApp.markerView = {
	__proto__: drwApp.elementStyleView,
	// input id list
	inputIds : [],
	// button id list
	btnIds : ["marker-start-choose-btn","marker-start-remove-btn","marker-mid-choose-btn","marker-mid-remove-btn","marker-end-choose-btn","marker-end-remove-btn"],
	labelIds:["marker-start","marker-mid","marker-end"],
	clearMarkerFields : function() {
		console.log("drwApp.markerView.clearMarkerFields");
		this.clearInputValues(this.inputIds);
		this.clearLabels(this.labelIds);
	},
	setMarkerFieldsEnabled : function(b) {
		console.log("drwApp.markerView.setMarkerFieldsEnabled "+b);
		this.setDisabled(this.inputIds.concat(this.btnIds),b==true ? false : true);
	},
	setMarkerStart : function(v) {
		console.log("drwApp.markerView.setMarkerStart "+v);
		this.setLabel("marker-start",v.getAttribute("id"));
	},
	setMarkerMid : function(v) {
		console.log("drwApp.markerView.setMarkerMid "+v);
		this.setLabel("marker-mid",v.getAttribute("id"));
	},
	setMarkerEnd : function(v) {
		console.log("drwApp.markerView.setMarkerEnd "+v);
		this.setLabel("marker-end",v.getAttribute("id"));
	},
	removeMarkerStart : function() {
		console.log("drwApp.markerView.removeMarkerStart");
		this.setLabel("marker-start","");
	},
	removeMarkerMid : function() {
		console.log("drwApp.markerView.removeMarkerMid");
		this.setLabel("marker-mid","");
	},
	removeMarkerEnd : function() {
		console.log("drwApp.markerView.removeMarkerEnd");
		this.setLabel("marker-end","");
	},
	onCreateMarker : function(v) {
		console.log("drwApp.markerView.onCreateMarker "+v);
	},
	onModifyMarker : function(v) {
		console.log("drwApp.markerView.onModifyMarker "+v);
	},
	onDeleteMarker : function(id) {
		console.log("drwApp.markerView.onDeleteMarker "+id);
	},
	onSelectMarker : function(v) {
		console.log("drwApp.markerView.onSelectMarker "+v);
	}
}
drwApp.getMarkerStyleView = function() {return drwApp.markerView;};


// Register drwApp as svgEngineApp
window['svgEngineApp']=drwApp;

