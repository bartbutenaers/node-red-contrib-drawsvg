Put here your custom shape catalog files generated with drawsvg tool:
https://drawsvg.org/tools.html#shapemap:

Declare them in the index.json file like this:
[
{"index":1,"title":"Samples 1","file":"shape-samples1.svg"},
{"index":2,"title":"Samples 2","file":"shape-samples2.svg"}
]

You can define up to 4 catalogs.
Index must be between 1 and 4