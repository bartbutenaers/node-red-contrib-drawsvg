To customize drawsvg engine behaviour change parameters definition in parameters.json file.

Parameter "imageDefaultURL" define the default URL used by the image drawing task.
The value must begin with / to define an URL relative to the domain.